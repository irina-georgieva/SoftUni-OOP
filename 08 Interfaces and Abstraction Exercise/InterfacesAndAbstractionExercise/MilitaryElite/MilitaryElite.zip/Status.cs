﻿namespace MilitaryElite
{
    public enum Status
    {
        inProgress,
        Finished
    }
}
