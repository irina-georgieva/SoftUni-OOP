﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public interface IFood
    {
        public int Quantity { get; set; }
    }
}
